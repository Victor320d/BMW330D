document.addEventListener("DOMContentLoaded", () => {
    var swiper = new Swiper('.swiper', {
        slidesPerView: 3,
        spaceBetween: 10,
        autoHeight: true
    });
});